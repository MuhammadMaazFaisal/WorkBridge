<!-- Footer -->
<div class="dashboard-footer-spacer"></div>
			<div class="small-footer margin-top-15">
				<div class="small-footer-copyrights">
					© 2023 <strong><a href="mailto:m.maazfaisal0301@gmail.com"></a></strong>. All Rights Reserved.
				</div>
				<div class="clearfix"></div>
			</div>
			<!-- Footer / End -->